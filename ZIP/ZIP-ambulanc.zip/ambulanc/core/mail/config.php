<?php
/**
 * Az email kuldes konfiguracios allomanya
 * Keszitette: Bozsik Armand Viktor
 */
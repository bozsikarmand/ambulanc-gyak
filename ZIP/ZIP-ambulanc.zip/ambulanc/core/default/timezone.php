<?php

define('DEFAULT_TZ', 'Europe/Budapest');


date_default_timezone_set(DEFAULT_TZ);
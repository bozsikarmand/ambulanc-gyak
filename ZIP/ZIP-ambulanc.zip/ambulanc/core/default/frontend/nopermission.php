<?php 

echo "Nincs megfelelő jogosultságod a funkció eléréséhez!";
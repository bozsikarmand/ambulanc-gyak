<?php

$USER = 1;
$ADMIN = 2;
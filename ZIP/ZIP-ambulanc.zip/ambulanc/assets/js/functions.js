function windowPrint() {
    window.print();
}
function windowClose() {
    window.close();
}
A fajlokat fel kell masolni a szerverre.
Az adatbazist letre kell hozni utf8mb4_unicode_ci kodolassal, majd be kell importalni az adatbazis fajlt MySQL alatt.
A core/mail/sender.php-ban illetve a database/config.php-ban meg kell adni a vonatkozo adatokat.
Regisztralni kell az oldalra, majd a szemelyjog tablaban a jogID-t 2-re allitani, a szemely tablabvan pedig a statusz-t 6-ra.
(Az install szkript elkeszitese - ami ezt elvegezne - meg folyamatban van.)